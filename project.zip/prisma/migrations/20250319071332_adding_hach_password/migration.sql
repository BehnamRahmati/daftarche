-- AlterTable
ALTER TABLE "User" ADD COLUMN     "hashedPassword" TEXT;
