// lib/s3.ts - MinIO client configuration
// import { S3Client } from '@aws-sdk/client-s3'

// const s3Client = new S3Client({
//     endpoint: process.env.MINIO_ENDPOINT,
//     region: 'default',
//     credentials: {
//         accessKeyId: process.env.MINIO_ACCESS_KEY!,
//         secretAccessKey: process.env.MINIO_SECRET_KEY!,
//     },
//     forcePathStyle: true, // Required for MinIO
// })

// export { s3Client }

