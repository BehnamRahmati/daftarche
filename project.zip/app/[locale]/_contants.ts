export type TParamsLocale = {
    params : Promise<{locale: 'en' | 'fa'}>
}