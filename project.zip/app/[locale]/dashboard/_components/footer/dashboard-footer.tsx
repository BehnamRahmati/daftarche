
import React from 'react'

export default function DashboardFooter() {
    return (
        <footer className='bg-sidebar p-2.5 border-t border-t-sidebar-border leading-7'>
            <p className='text-center'>made with class by Behnam</p>
        </footer>
    )
}
